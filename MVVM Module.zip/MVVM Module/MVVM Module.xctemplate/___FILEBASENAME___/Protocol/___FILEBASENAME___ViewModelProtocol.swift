//  ___FILEHEADER___

import Foundation

public protocol ___FILEBASENAME___: AnyObject {
    var delegate: ___VARIABLE_productName:identifier___ViewModelDelegate? { get set }
    func load()
}

public protocol ___VARIABLE_productName:identifier___ViewModelDelegate: AnyObject {
    func handle(output: ___VARIABLE_productName:identifier___ViewModelOutput)
}

public enum ___VARIABLE_productName:identifier___ViewModelOutput {
    case fetched
}