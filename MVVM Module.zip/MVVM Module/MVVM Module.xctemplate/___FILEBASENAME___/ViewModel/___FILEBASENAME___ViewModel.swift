//  ___FILEHEADER___

import Foundation

final class ___FILEBASENAME___: ___VARIABLE_productName:identifier___ViewModelProtocol {

    public weak var delegate: ___VARIABLE_productName:identifier___ViewModelDelegate?

    // MARK: - Public Methods
    public func load() {
        
    }
    
}